package com.hoktop.lanchat;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.hoktop.lanchat.login.login;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.AccessController;
import java.security.acl.Group;

import static java.security.AccessController.getContext;


public class Chat extends AppCompatActivity {
    static final int SocketServerPORT = 8080;
    TextView infoIp, infoPort, chasstsMsg;
    EditText edtMsg;
    Button btnSen1dMsg;
    ScrollView scrollView2;
    String ReceverServerChatMsg;
    String clientSenderMsg = "";
    EditText nameinput;
    EditText ipinput;
    String getchat;
    String inputchat;
    boolean Strin = true;
    Service service = new Service();
    String name;
    String ip = "";
    String ip2 = "";
    Socket socket;
    DataOutputStream send;
    ServerSocket serverSocket;
    DataInputStream get;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        scrollView2 = findViewById(R.id.srcmasg);
        infoIp = findViewById(R.id.iploginChat);
        edtMsg = findViewById(R.id.Message);
        chasstsMsg = findViewById(R.id.hhhchat);
        btnSen1dMsg = findViewById(R.id.sender);
        infoIp.setText(service.getIpAddress());
        Intent intent = getIntent();
        name = intent.getStringExtra(login.EXTRA_MESSAGE);
        ip = intent.getStringExtra(login.EXTRA_MESSAGE2);
        nameinput= new EditText(this);
        ipinput= new EditText(this);
        if (ip != null) {
            //if he sender call class background 2
            new backgruond2().execute();
        } else {
            //if he Receiver call class background 1
            new backgruond().execute();
        }
        ///Button send message
        btnSen1dMsg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ///get data in EditTxt AND SAVE in clientSenderMsg
                clientSenderMsg = edtMsg.getText().toString();
                ///add string data in clientSenderMsg for Textview this for show your sanded message
                chasstsMsg.append("\n my:"+clientSenderMsg);

            }
        });
    }
    //class prossing in backgruond 1
    private   class backgruond extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            //call function send
            gett();
            return null;
        }
    }
    //class prossing in backgruond 2
    private   class backgruond2 extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            //call function send
            send();
            return null;
        }
    }

    //function send
    public void send() {
        try{
            //create socket Connected //Requirements for connect socket ip and port Socket server
            socket = new Socket(ip,SocketServerPORT);
            //using DataOutputStream for send data
            send = new DataOutputStream(socket.getOutputStream());
            //using DataInputStream for get data
            get = new DataInputStream(socket.getInputStream());
            //if succeeded connected Socket
            if (socket.isConnected()){
                //Message content
                send.writeUTF("login by:"+name);
                //send Message
                send.flush();
            };
            //loop for get any message come new and send new message
            while (socket.isConnected()){
                send = new DataOutputStream(socket.getOutputStream());
                get = new DataInputStream(socket.getInputStream());
                //if you have new message to send
                if (!clientSenderMsg.equals("")){
                    //Message content
                    send.writeUTF("message by :"+name+":"+clientSenderMsg+"\n");
                    //send Message
                    send.flush();
                    //clean  content clientSenderMsg
                    clientSenderMsg = "";
                    this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            //clean  content EdITTEXT edtMsg from old message sended from me
                            edtMsg.setText("");
                        }
                    });
                }
                // if i have new message send to me apply in Text View chasstsMsg
                if (get.available() >0){
                    //read data and convert to string you can read it and save in ReceverServerChatMsg
                    ReceverServerChatMsg = get.readUTF();
                    this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            ///add string data in ReceverServerChatMsg for Textview this for show your sanded message
                            chasstsMsg.append(ReceverServerChatMsg+"\n");
                        }
                    });
                }

            }
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    //function get
    public void gett(){
        try{
            //create ServerSocket Connected //Requirements for connect  port Socket server
            //he listening porting
            serverSocket = new ServerSocket(SocketServerPORT);
            //is for like Means approval of clint  contact
            socket = serverSocket.accept();
            //using DataOutputStream for send data
            send = new DataOutputStream(socket.getOutputStream());
            //using DataInputStream for get data
            get = new DataInputStream(socket.getInputStream());
            //if succeeded connected Socket
            if (socket.isConnected()){
                //get ip address for clint connected me and save he in name
                name = socket.getInetAddress().toString();
                //send this message to reply this connected /message content
                send.writeUTF("login by:"+name);
                //send message
                send.flush();
            };
            //loop for get any message come new and send new message
            while (socket.isConnected()){
                //using DataOutputStream for send data
                send = new DataOutputStream(socket.getOutputStream());
                //using DataInputStream for get data
                get = new DataInputStream(socket.getInputStream());
                //if you have new message to send
                if (!clientSenderMsg.equals("")){
                    //Message content
                    send.writeUTF("message by :"+name+":"+clientSenderMsg+"\n");
                    //send message
                    send.flush();
                    //clean clientSenderMsg data
                    clientSenderMsg = "";
                    //clean  content EdITTEXT edtMsg from old message sended from me
                    this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            edtMsg.setText("");
                        }
                    });
                }
                // if i have new message send to me apply in Text View chasstsMsg
                if (get.available() >0){
                    //read data and convert to string you can read it and save in ReceverServerChatMsg
                    ReceverServerChatMsg = get.readUTF();
                    this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            ///add string data in ReceverServerChatMsg for Textview this for show your sanded message
                            chasstsMsg.append(ReceverServerChatMsg+"\n");
                        }
                    });
                }

            }
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    //this method if you out chat he close connect
    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (serverSocket != null) {
            try {
                serverSocket.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        if (socket != null) {
            try {
                socket.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

    }
}



