package com.hoktop.lanchat;

import android.content.Intent;
import android.net.Network;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import java.io.DataInputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

public class Service {
    ServerSocket serverSocket;

    //List CLIENT USERS IN CONNECTED
    List<Service.ChatClient> userList;
    public void start(){
        new Send().execute();
    };
    //GET IP ADDRESS
    public String getIpAddress(){
        String ip = null;
        try {
            Enumeration<NetworkInterface>enumNetworkInterface = NetworkInterface
                    .getNetworkInterfaces();
            while (enumNetworkInterface.hasMoreElements()){
                NetworkInterface networkInterface = enumNetworkInterface.nextElement();
                Enumeration<InetAddress>enumeration = networkInterface.getInetAddresses();
                while (enumeration.hasMoreElements()){
                    InetAddress inetAddress = enumeration.nextElement();
                    if (inetAddress.isSiteLocalAddress()){
                        ip = "Address Chat:"+ inetAddress.getHostAddress();
                    }
                }

            }
        } catch (SocketException e) {
            e.printStackTrace();
            ip += "Something Wrong! Pro " + e.toString() + "\n";
        }
        return ip;
    }


    //////////////////////////////
    static class Send extends AsyncTask<String,Integer,String>{

        @Override
        protected String doInBackground(String... strings) {
            DataOutputStream dataOutputStream = null;
            try {
                Socket socket= new Socket("192.168.1.2",8080);
                dataOutputStream = new DataOutputStream(socket.getOutputStream());
                dataOutputStream.writeUTF("hoktop");
                dataOutputStream.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;

        }
    }
    static class Get extends AsyncTask<String,Integer,String>{

        @Override
        protected String doInBackground(String... strings) {
            DataInputStream dataInputStream = null;
            try {
                Socket socket= new Socket("127.0.0.1",8080);
                dataInputStream = new DataInputStream(socket.getInputStream());
               String S = dataInputStream.readUTF();
                Log.v("t",S);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    public class ChatClient {
        String name;
        Socket socket;
    }
}
