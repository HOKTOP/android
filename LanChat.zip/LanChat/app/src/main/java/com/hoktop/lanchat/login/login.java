package com.hoktop.lanchat.login;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.hoktop.lanchat.Chat;
import com.hoktop.lanchat.MainActivity;
import com.hoktop.lanchat.R;

public class login extends AppCompatActivity {
    public static final String EXTRA_MESSAGE = "nickname";
    public static final String EXTRA_MESSAGE2 = "iplogin";
    public static final String EXTRA_MESSAGE3 = "SocetPort";


    static final int SocetPort = 8080;

    EditText iplogin,nikname;
    TextView logoa;
    Button loginchat;
    String activte;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        iplogin = findViewById(R.id.ipChat);
        logoa = findViewById(R.id.logo);
        nikname = findViewById(R.id.nickname);
        loginchat = findViewById(R.id.loginbutt);
        final Intent intent =getIntent();
        if(activte!="login"){
            iplogin.setVisibility(View.INVISIBLE);
            loginchat.setText("CReate ");
            logoa.setText("CrEATE CHAT");

        }
        activte = intent.getStringExtra(MainActivity.KAY);
        loginchat.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               if(activte=="login"){
                   Intent chat = new Intent(login.this,Chat.class);
                   String name = nikname.getText().toString();
                   String ip = iplogin.getText().toString();
                   chat.putExtra(EXTRA_MESSAGE,name);
                   chat.putExtra(EXTRA_MESSAGE2,ip);
                   if (ip==""){
                       Toast.makeText(login.this,"please CHECK YOUR Nickname AND IP",Toast.LENGTH_SHORT).show();
                   }
                   startActivity(chat);

               }else if (activte=="create"){
                   Intent chat = new Intent(login.this,Chat.class);
                   String name = nikname.getText().toString();
                   chat.putExtra(EXTRA_MESSAGE,name);
                   startActivity(chat);
               }
           }
       });
    }

}
